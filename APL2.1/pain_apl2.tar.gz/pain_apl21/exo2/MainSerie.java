public class MainSerie{

	public static void main(String[] args) {

		Serie serie01 = new Serie(a,3);
		System.out.println(serie01.toString());

	}	
}